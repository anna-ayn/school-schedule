#ifndef _propdense_h_INCLUDED
#define _propdense_h_INCLUDED

#include <stdbool.h>
#include <limits.h>

struct kissat;

bool kissat_dense_propagate (struct kissat *);

#endif
