#ifndef _sweep_h_INCLUDED
#define _sweep_h_INCLUDED

struct kissat;
void kissat_sweep (struct kissat *);

#endif
