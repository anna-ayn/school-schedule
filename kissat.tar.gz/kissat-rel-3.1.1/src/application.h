#ifndef _application_h_INCLUDED
#define _application_h_INCLUDED

struct kissat;

int kissat_application (struct kissat *, int argc, char **argv);

#endif
